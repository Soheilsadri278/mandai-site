TAKINTA STATIC SITE THEME

Install this ZIP from WordPress Admin > Appearance > Themes > Add New > Upload Theme.
After activation, open Settings > Permalinks, choose Post name, and save once.

This theme serves the bundled static HTML pages and assets. Content is not editable as WordPress posts/pages. Search uses the bundled bilingual page index. Cart and account features are independent of WooCommerce; no checkout or payment is enabled.

A Persian installation guide (INSTALL-FA.md) is distributed next to this ZIP.
