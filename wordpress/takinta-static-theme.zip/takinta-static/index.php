<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main class="takinta-wp-fallback">
  <h1><?php esc_html_e('Page not found', 'takinta-static'); ?></h1>
  <p><?php esc_html_e('Check the address or return to the home page.', 'takinta-static'); ?></p>
  <p><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'takinta-static'); ?></a></p>
</main>
<?php get_footer(); ?>
