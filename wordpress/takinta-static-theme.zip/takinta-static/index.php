<?php
if (!defined('ABSPATH')) { exit; }
get_header();
$is_commerce = function_exists('is_cart') && (is_cart() || is_checkout() || (function_exists('is_account_page') && is_account_page()) || (function_exists('is_woocommerce') && is_woocommerce()));
if ($is_commerce) {
    $home = home_url('/');
    $logo = get_template_directory_uri() . '/static-site/images/logo.png';
    $is_fa = is_rtl();
    ?>
    <header class="site-header"><div class="container site-header__main">
      <a href="<?php echo esc_url($home); ?>" class="site-header__logo" aria-label="Takinta home"><img src="<?php echo esc_url($logo); ?>" alt="Takinta" class="site-header__logo-img"></a>
      <nav class="takinta-commerce-nav" aria-label="Store navigation">
        <a href="<?php echo esc_url($home); ?>"><?php echo esc_html($is_fa ? 'صفحهٔ اصلی' : 'Home'); ?></a>
        <?php if (function_exists('wc_get_cart_url')) : ?><a href="<?php echo esc_url(wc_get_cart_url()); ?>"><?php echo esc_html($is_fa ? 'سبد خرید' : 'Shopping cart'); ?></a><?php endif; ?>
      </nav>
    </div></header>
    <style>.takinta-commerce-nav{display:flex;gap:20px;margin-inline-start:auto}.takinta-commerce-nav a{color:inherit;text-decoration:none;font-weight:600}.takinta-commerce-content{max-width:1200px;margin:38px auto 64px;padding-inline:20px}.takinta-commerce-content>h1{margin:0 0 24px;font-size:clamp(28px,4vw,40px)}.takinta-commerce-footer{padding:28px 20px;text-align:center;background:#f4f3f1;color:#59665c}</style>
    <main class="woocommerce takinta-commerce-content" dir="<?php echo esc_attr($is_fa ? 'rtl' : 'ltr'); ?>">
      <?php while (have_posts()) : the_post(); ?><h1><?php the_title(); ?></h1><?php the_content(); ?><?php endwhile; ?>
    </main>
    <footer class="takinta-commerce-footer">© <?php echo esc_html((string) gmdate('Y')); ?> Takinta</footer>
    <?php
} else {
    ?>
    <main class="takinta-wp-fallback">
      <h1><?php esc_html_e('Page not found', 'takinta-static'); ?></h1>
      <p><?php esc_html_e('Check the address or return to the home page.', 'takinta-static'); ?></p>
      <p><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'takinta-static'); ?></a></p>
    </main>
    <?php
}
get_footer();
?>
