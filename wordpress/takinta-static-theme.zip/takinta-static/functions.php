<?php
/**
 * WordPress route wrapper for the original bilingual static pages.
 * Page markup and assets remain bundled in static-site/.
 */
if (!defined('ABSPATH')) { exit; }

define('TAKINTA_STATIC_DIR', get_template_directory() . '/static-site');
define('TAKINTA_STATIC_THEME_TOKEN', '__TAKINTA_THEME_URI__');
define('TAKINTA_STATIC_HOME_TOKEN', '__TAKINTA_HOME_URL__');

function takinta_static_register_routes() {
    add_rewrite_tag('%takinta_static%', '(.+)');
    add_rewrite_tag('%takinta_contact%', '([0-1])');
    add_rewrite_rule('^contact\.php$', 'index.php?takinta_contact=1', 'top');
    add_rewrite_rule('^fa/?$', 'index.php?takinta_static=fa/index.html', 'top');
    add_rewrite_rule('^(.+\.html)$', 'index.php?takinta_static=$matches[1]', 'top');
}
add_action('init', 'takinta_static_register_routes');

function takinta_static_query_vars($vars) {
    $vars[] = 'takinta_static';
    $vars[] = 'takinta_contact';
    return $vars;
}
add_filter('query_vars', 'takinta_static_query_vars');
add_action('after_switch_theme', 'flush_rewrite_rules');

function takinta_static_redirect_default_home_to_persian() {
    if (is_admin() || is_preview() || !is_front_page()) { return; }
    if (isset($_GET['lang']) && sanitize_key(wp_unslash($_GET['lang'])) === 'en') { return; }
    $request_path = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $request_path = untrailingslashit((string) parse_url($request_path, PHP_URL_PATH));
    $home_path = untrailingslashit((string) parse_url(home_url('/'), PHP_URL_PATH));
    if ($request_path !== $home_path) { return; }
    nocache_headers();
    wp_safe_redirect(home_url('/fa/'), 302, 'Takinta Persian default language');
    exit;
}
add_action('template_redirect', 'takinta_static_redirect_default_home_to_persian', -5);

function takinta_static_json($ok, $message = '', $extra = array(), $status = 200) {
    wp_send_json(array_merge(array('ok' => (bool) $ok, 'error' => $ok ? '' : $message), $extra), $status);
}

function takinta_static_contact_endpoint() {
    if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        takinta_static_json(false, 'Method not allowed.', array(), 405);
    }

    // Honeypot: return a quiet success to automated spam submissions.
    if (!empty($_POST['company'])) {
        takinta_static_json(true);
    }

    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    if (!$email || !is_email($email)) {
        takinta_static_json(false, 'Please enter a valid email address.', array(), 400);
    }

    $form_type = sanitize_key(wp_unslash($_POST['form_type'] ?? 'contact'));
    if ($form_type === 'newsletter') {
        $subscribers = get_option('takinta_static_newsletter_subscribers', array());
        if (!is_array($subscribers)) { $subscribers = array(); }
        foreach ($subscribers as $saved_email) {
            if (strtolower((string) $saved_email) === strtolower($email)) {
                takinta_static_json(true, '', array('duplicate' => true));
            }
        }
        $subscribers[] = $email;
        update_option('takinta_static_newsletter_subscribers', $subscribers, false);
        takinta_static_json(true, '', array('saved' => true));
    }

    $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
    $source = sanitize_text_field(wp_unslash($_POST['source'] ?? ''));
    if ($name === '' || $message === '') {
        takinta_static_json(false, 'Please fill in all required fields (name and message).', array(), 400);
    }
    if (strlen($message) > 15000) {
        takinta_static_json(false, 'Message is too long.', array(), 400);
    }

    $recipient = apply_filters('takinta_static_contact_recipient', get_option('admin_email'));
    if (!is_email($recipient)) {
        takinta_static_json(false, 'Set a valid site administration email in WordPress Settings.', array(), 500);
    }
    $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
    $subject = sprintf('[%s] New contact message from %s', $site_name, $name);
    $body = "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\nSource: {$source}\n\nMessage:\n{$message}\n";
    $headers = array('Reply-To: ' . $name . ' <' . $email . '>');
    if (!wp_mail($recipient, $subject, $body, $headers)) {
        takinta_static_json(false, 'Could not send the message. Please try again or call us directly.', array(), 500);
    }
    takinta_static_json(true, '', array('mailed' => true));
}

function takinta_static_render_route() {
    if (get_query_var('takinta_contact')) {
        takinta_static_contact_endpoint();
    }

    $route = (string) get_query_var('takinta_static');
    if ($route === '' && is_front_page()) {
        $route = isset($_GET['lang']) && sanitize_key(wp_unslash($_GET['lang'])) === 'en' ? 'index.html' : 'fa/index.html';
    }
    if ($route === '') { return; }

    $route = rawurldecode($route);
    $route = str_replace('\\', '/', $route);
    if (strpos($route, "\0") !== false || preg_match('#(^|/)\.\.(/|$)#', $route)) {
        status_header(400);
        exit;
    }
    $root = realpath(TAKINTA_STATIC_DIR);
    $file = $root ? realpath($root . DIRECTORY_SEPARATOR . ltrim($route, '/')) : false;
    if (!$root || !$file || strpos($file, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($file)) {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        return;
    }

    $document = file_get_contents($file);
    if ($document === false) {
        status_header(500);
        exit;
    }
    $document = preg_replace('~<button\b[^>]*\bdata-demo="Country selector"[^>]*>.*?</button\s*>~is', '', $document);
    $theme_uri = untrailingslashit(get_template_directory_uri());
    $home_url = untrailingslashit(home_url('/'));
    $document = str_replace(TAKINTA_STATIC_THEME_TOKEN, esc_url_raw($theme_uri), $document);
    $document = str_replace(TAKINTA_STATIC_HOME_TOKEN, esc_url_raw($home_url), $document);
    $document = str_replace(array('https://www.example.com', 'http://www.example.com'), $home_url, $document);
    $document = str_replace($home_url . '/images/', $theme_uri . '/static-site/images/', $document);

    status_header(200);
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    echo $document;
    exit;
}
add_action('template_redirect', 'takinta_static_render_route', 0);

function takinta_static_newsletter_admin_menu() {
    add_management_page('Takinta Newsletter', 'Takinta Newsletter', 'manage_options', 'takinta-static-newsletter', 'takinta_static_newsletter_admin_page');
}
add_action('admin_menu', 'takinta_static_newsletter_admin_menu');

function takinta_static_newsletter_admin_page() {
    if (!current_user_can('manage_options')) { return; }
    $subscribers = get_option('takinta_static_newsletter_subscribers', array());
    if (!is_array($subscribers)) { $subscribers = array(); }
    if (isset($_GET['export']) && $_GET['export'] === '1') {
        check_admin_referer('takinta_static_newsletter_export');
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename=takinta-newsletter-subscribers.csv');
        echo "\xEF\xBB\xBF";
        $output = fopen('php://output', 'w');
        fputcsv($output, array('email'));
        foreach ($subscribers as $email) { fputcsv($output, array(sanitize_email($email))); }
        fclose($output);
        exit;
    }
    $export_url = wp_nonce_url(add_query_arg('export', '1', admin_url('tools.php?page=takinta-static-newsletter')), 'takinta_static_newsletter_export');
    echo '<div class="wrap"><h1>Takinta Newsletter</h1>';
    echo '<p>Subscribers are stored in the WordPress database. Connect a mailing-list provider and apply your privacy/consent policy before sending campaigns.</p>';
    echo '<p><strong>Total:</strong> ' . esc_html((string) count($subscribers)) . ' &nbsp; <a class="button button-primary" href="' . esc_url($export_url) . '">Export CSV</a></p>';
    if (!$subscribers) {
        echo '<p>No subscribers yet.</p>';
    } else {
        echo '<table class="widefat striped"><thead><tr><th>Email</th></tr></thead><tbody>';
        foreach ($subscribers as $email) { echo '<tr><td>' . esc_html(sanitize_email($email)) . '</td></tr>'; }
        echo '</tbody></table>';
    }
    echo '</div>';
}

function takinta_static_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('woocommerce');
}
add_action('after_setup_theme', 'takinta_static_theme_setup');

function takinta_static_requested_commerce_language() {
    if (isset($_GET['lang'])) {
        $language = sanitize_key(wp_unslash($_GET['lang']));
        if (in_array($language, array('fa', 'en'), true)) { return $language; }
    }
    if (isset($_COOKIE['takinta_commerce_language'])) {
        $language = sanitize_key(wp_unslash($_COOKIE['takinta_commerce_language']));
        if (in_array($language, array('fa', 'en'), true)) { return $language; }
    }
    return '';
}

function takinta_static_remember_commerce_language() {
    if (is_admin() || headers_sent()) { return; }
    $language = '';
    if (isset($_GET['lang'])) {
        $candidate = sanitize_key(wp_unslash($_GET['lang']));
        if (in_array($candidate, array('fa', 'en'), true)) { $language = $candidate; }
    }
    $request_path = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $request_path = (string) parse_url($request_path, PHP_URL_PATH);
    if ($language === '' && preg_match('#^/fa(?:/|$)#', $request_path)) { $language = 'fa'; }
    if ($language === '') { return; }
    if (isset($_COOKIE['takinta_commerce_language']) && $_COOKIE['takinta_commerce_language'] === $language) { return; }
    $options = array(
        'expires' => time() + (30 * DAY_IN_SECONDS),
        'path' => defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
        'secure' => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    );
    if (defined('COOKIE_DOMAIN') && COOKIE_DOMAIN !== '') { $options['domain'] = COOKIE_DOMAIN; }
    setcookie('takinta_commerce_language', $language, $options);
    $_COOKIE['takinta_commerce_language'] = $language;
}
add_action('init', 'takinta_static_remember_commerce_language', 1);

function takinta_static_is_persian_commerce_request() {
    $language = takinta_static_requested_commerce_language();
    if ($language === 'fa') { return true; }
    if ($language === 'en') { return false; }
    return function_exists('is_rtl') && is_rtl();
}

function takinta_static_switch_to_persian_commerce_locale() {
    if (is_admin() || !takinta_static_is_persian_commerce_request()) { return; }
    if (function_exists('switch_to_locale')) { switch_to_locale('fa_IR'); }
}
add_action('wp', 'takinta_static_switch_to_persian_commerce_locale', 0);

function takinta_static_persian_commerce_document_title($title) {
    if (is_admin() || !takinta_static_is_persian_commerce_request()) { return $title; }
    if (function_exists('is_cart') && is_cart()) { return 'سبد خرید'; }
    if (function_exists('is_checkout') && is_checkout()) { return 'تکمیل سفارش'; }
    return $title;
}
add_filter('pre_get_document_title', 'takinta_static_persian_commerce_document_title');

function takinta_static_persian_cart_translations() {
    return array(
        'Cart' => 'سبد خرید',
        'Shopping cart' => 'سبد خرید',
        'Cart totals' => 'جمع سبد خرید',
        'Checkout' => 'تکمیل سفارش',
        'Contact information' => 'اطلاعات تماس',
        'Email address' => 'نشانی ایمیل',
        'Shipping address' => 'نشانی ارسال',
        'Billing address' => 'نشانی صورتحساب',
        'Country/Region' => 'کشور/منطقه',
        'Iran' => 'ایران',
        'First name' => 'نام',
        'Last name' => 'نام خانوادگی',
        'Company name' => 'نام شرکت',
        'Company (optional)' => 'شرکت (اختیاری)',
        'State/County' => 'استان',
        'Alborz (البرز)' => 'البرز',
        'City' => 'شهر',
        'Address' => 'نشانی',
        'Address line 2' => 'نشانی تکمیلی',
        'Add apartment, suite, etc.' => 'افزودن واحد، سوئیت و غیره',
        '+ Add apartment, suite, etc.' => 'افزودن واحد، سوئیت و غیره',
        'Apartment, suite, etc.' => 'واحد، سوئیت و غیره',
        'Postal code' => 'کد پستی',
        'Phone (optional)' => 'تلفن (اختیاری)',
        'Use same address for billing' => 'استفاده از همین نشانی برای صورتحساب',
        'Shipping options' => 'روش‌های ارسال',
        'Payment options' => 'روش‌های پرداخت',
        'Order summary' => 'خلاصهٔ سفارش',
        'Order notes' => 'یادداشت سفارش',
        'Add a note to your order' => 'افزودن یادداشت به سفارش',
        'Place Order' => 'ثبت سفارش',
        'Place order' => 'ثبت سفارش',
        'Terms and Conditions' => 'شرایط و ضوابط',
        'Privacy Policy' => 'سیاست حفظ حریم خصوصی',
        'and' => 'و',
        'By proceeding with your purchase you agree to our' => 'با ادامهٔ خرید، موافقت می‌کنید با',
        'There are no payment methods available. Please contact us for help placing your order.' => 'در حال حاضر روش پرداختی در دسترس نیست. برای ثبت سفارش با ما تماس بگیرید.',
        'There are no shipping options available. Please ensure that your address has been entered correctly, or contact us if you need any help.' => 'روش ارسالی در دسترس نیست. نشانی را بررسی کنید یا برای راهنمایی با ما تماس بگیرید.',
        'Returning customer?' => 'قبلاً خرید کرده‌اید؟',
        'Click here to login' => 'برای ورود اینجا کلیک کنید',
        'Have a coupon?' => 'کد تخفیف دارید؟',
        'Click here to enter your code' => 'برای واردکردن کد تخفیف اینجا کلیک کنید',
        'Return to cart' => 'بازگشت به سبد خرید',
        'Add coupons' => 'افزودن کد تخفیف',
        'Add a coupon' => 'افزودن کد تخفیف',
        'Add coupon' => 'افزودن کد تخفیف',
        'Coupon code' => 'کد تخفیف',
        'Apply' => 'اعمال',
        'Free shipping' => 'ارسال رایگان',
        'Estimated total' => 'مجموع تقریبی',
        'Proceed to Checkout' => 'ادامه به پرداخت',
        'Proceed to checkout' => 'ادامه به پرداخت',
        'Subtotal' => 'جمع جزء',
        'Total' => 'مجموع',
        'Shipping' => 'هزینهٔ ارسال',
        'Quantity' => 'تعداد',
        'Product' => 'محصول',
        'Price' => 'قیمت',
        'Remove item' => 'حذف کالا',
        'Update cart' => 'به‌روزرسانی سبد خرید',
        'Continue shopping' => 'ادامهٔ خرید',
        'Keep shopping' => 'ادامهٔ خرید',
        'Browse store' => 'مشاهدهٔ فروشگاه',
        'Browse our store' => 'مشاهدهٔ فروشگاه',
        'Return to shop' => 'بازگشت به فروشگاه',
        'Your cart is currently empty!' => 'سبد خرید شما خالی است.',
        'Your cart is currently empty.' => 'سبد خرید شما خالی است.',
        'Your cart is empty.' => 'سبد خرید شما خالی است.',
        'There are no products in your cart.' => 'سبد خرید شما خالی است.',
        'Shipping options will be updated during checkout.' => 'گزینه‌های ارسال هنگام تکمیل سفارش به‌روزرسانی می‌شوند.',
    );
}

function takinta_static_translate_persian_cart_string($translation, $text) {
    if (is_admin() || !takinta_static_is_persian_commerce_request()) { return $translation; }
    $map = takinta_static_persian_cart_translations();
    if (isset($map[$text])) { return $map[$text]; }
    if (isset($map[$translation])) { return $map[$translation]; }
    return $translation;
}
add_filter('gettext', function($translation, $text, $domain) {
    return takinta_static_translate_persian_cart_string($translation, $text);
}, 20, 3);
add_filter('gettext_with_context', function($translation, $text, $context, $domain) {
    return takinta_static_translate_persian_cart_string($translation, $text);
}, 20, 4);

function takinta_static_preserve_persian_commerce_language($url) {
    $language = takinta_static_requested_commerce_language();
    if ($language === '' && takinta_static_is_persian_commerce_request()) { $language = 'fa'; }
    if (in_array($language, array('fa', 'en'), true)) { return add_query_arg('lang', $language, $url); }
    return $url;
}
add_filter('woocommerce_get_cart_url', 'takinta_static_preserve_persian_commerce_language', 20);
add_filter('woocommerce_get_checkout_url', 'takinta_static_preserve_persian_commerce_language', 20);
add_filter('woocommerce_return_to_shop_redirect', 'takinta_static_preserve_persian_commerce_language', 20);

function takinta_static_enqueue_commerce_assets() {
    $commerce_page = function_exists('is_cart') && (is_cart() || is_checkout() || (function_exists('is_account_page') && is_account_page()) || (function_exists('is_woocommerce') && is_woocommerce()));
    if (!$commerce_page) { return; }
    $base = untrailingslashit(get_template_directory_uri()) . '/static-site/assets/css/';
    wp_enqueue_style('takinta-static-commerce', $base . 'style.css', array(), '1.1.0');
    wp_enqueue_style('takinta-static-commerce-product', $base . 'product-page.css', array('takinta-static-commerce'), '1.1.0');
    if (takinta_static_is_persian_commerce_request()) { wp_enqueue_style('takinta-static-commerce-rtl', $base . 'rtl.css', array('takinta-static-commerce'), '1.1.0'); }
}
add_action('wp_enqueue_scripts', 'takinta_static_enqueue_commerce_assets');
